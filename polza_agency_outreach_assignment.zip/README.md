# Polza Agency outreach test assignment

Пакет содержит базу B2B-компаний, персонализацию, отдельную обработку таблицы на 15 компаний, цепочку писем, скрипт и QA-отчёт.

## Запуск

```powershell
$env:PYTHONPATH='src'; python -m pytest tests -q
$env:PYTHONPATH='src'; python scripts/build_deliverables.py
```

Скрипт не отправляет письма и не проверяет доставляемость email. Перед реальной рассылкой нужна ручная проверка выборки, юридическая проверка оснований контакта и настройка deliverability.
