# Quality report

- Итоговых строк в основной базе: 55.
- Строк в задаче 4: 15.
- Role-based email: 35.
- Email status breakdown: {'role_based_unverified': 14, 'personal_public': 19, 'role_based_public': 14, 'domain_mismatch_review': 7, 'mx_not_found_review': 1}.
- Тройная email-проверка: синтаксис, DNS/MX домена email, наличие email на указанной странице-источнике где сайт отдал страницу.
- Результат email-проверки: 0 синтаксических ошибок; 1 email-домен без MX; 7 строк с отличающимся доменом email; доставляемость SMTP/API не подтверждалась.
- Строк основной базы на ручную проверку: 21.
- Строк задачи 4 с mismatch email/domain: 5.
- Unit-тесты personalization.py проходят.
- Ограничение: SMTP/API deliverability не запускалась; персональные email не подбирались догадкой.
