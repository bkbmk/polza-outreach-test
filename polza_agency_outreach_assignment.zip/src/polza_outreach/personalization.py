from __future__ import annotations

from urllib.parse import urlparse


ROLE_PREFIXES = {
    "sales",
    "info",
    "hello",
    "contact",
    "office",
    "marketing",
    "partners",
    "commercial",
    "export",
}


def normalize_domain(value: str) -> str:
    raw = (value or "").strip().lower()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = parsed.netloc or parsed.path.split("/")[0]
    return host.removeprefix("www.")


def classify_email(email: str, domain: str, source_url: str = "") -> str:
    email_clean = (email or "").strip().lower()
    domain_clean = normalize_domain(domain)
    if "@" not in email_clean or not domain_clean:
        return "missing_or_invalid"
    local, email_domain = email_clean.rsplit("@", 1)
    if normalize_domain(email_domain) != domain_clean:
        return "domain_mismatch_review"
    if local in ROLE_PREFIXES or local.startswith(("sales", "info", "hello", "contact")):
        return "role_based_public" if source_url else "role_based_unverified"
    return "personal_public" if source_url else "personal_unverified"


def calculate_confidence(record: dict) -> int:
    score = 0
    if record.get("decision_maker_name") and record.get("decision_maker_profile_url"):
        score += 15
    if record.get("decision_maker_role"):
        score += 15
    email_status = record.get("email_verification_status", "")
    if email_status == "personal_public":
        score += 25
    elif email_status == "role_based_public":
        score += 15
    elif email_status in {"personal_unverified", "role_based_unverified"}:
        score += 5
    if record.get("email") and normalize_domain(record.get("domain", "")) in record.get("email", "").lower():
        score += 10
    if record.get("personalization_source_url"):
        score += 10
    if record.get("personalization_source_date"):
        score += 5
    if record.get("b2b_evidence_url"):
        score += 10
    return min(score, 100)


def build_personalization(record: dict) -> str:
    company = record.get("company_name", "компании")
    fact = record.get("company_fact") or record.get("b2b_evidence") or "есть проверяемый B2B-сигнал"
    angle = record.get("outreach_angle") or "обсудить аккуратный запуск outbound без нагрузки на отдел продаж"
    return f"У {company} есть конкретный сигнал для B2B-аутрича: {fact}. Логичный угол письма: {angle}."
