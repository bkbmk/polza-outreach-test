from polza_outreach.personalization import (
    build_personalization,
    calculate_confidence,
    classify_email,
    normalize_domain,
)


def test_normalize_domain_removes_scheme_path_and_www():
    assert normalize_domain("https://www.example.ru/path?q=1") == "example.ru"


def test_classify_email_marks_matching_role_address():
    assert classify_email("sales@example.ru", "example.ru", "https://example.ru/contacts") == "role_based_public"


def test_confidence_rewards_public_sources_and_personalization():
    record = {
        "decision_maker_name": "Иван Иванов",
        "decision_maker_role": "Коммерческий директор",
        "decision_maker_profile_url": "https://example.ru/team",
        "email": "sales@example.ru",
        "domain": "example.ru",
        "email_source_url": "https://example.ru/contacts",
        "email_verification_status": "role_based_public",
        "personalization_source_url": "https://example.ru/cases",
        "personalization_source_date": "2026-07-26",
        "b2b_evidence_url": "https://example.ru/b2b",
    }

    assert calculate_confidence(record) == 80


def test_build_personalization_uses_company_fact_and_angle():
    record = {
        "company_name": "Example",
        "company_fact": "публикует B2B-кейсы по внедрению CRM",
        "outreach_angle": "предложить системный outbound к похожим сегментам",
    }

    assert build_personalization(record) == (
        "У Example есть конкретный сигнал для B2B-аутрича: публикует B2B-кейсы по внедрению CRM. "
        "Логичный угол письма: предложить системный outbound к похожим сегментам."
    )
